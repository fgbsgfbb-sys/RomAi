package com.example.romai.jni
object LlamaBridge {
    external fun loadModel(path: String, memFile: String, useRam: Boolean): Boolean
    external fun prompt(text: String, temp: Float, topP: Float, topK: Int): String
    init { System.loadLibrary("romai") }
}
