package com.example.romai.presentation
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.romai.data.local.ChatDao
import com.example.romai.data.local.Chat
import com.example.romai.data.repository.ModelRepository
import com.example.romai.manager.DownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
@HiltViewModel class MainViewModel @Inject constructor(private val repo: ModelRepository, private val dao: ChatDao, private val dlManager: DownloadManager) : ViewModel() {
    private val _chats = MutableStateFlow<List<Chat>>(emptyList())
    val chats: StateFlow<List<Chat>> = _chats.asStateFlow()
    val downloadTasks = dlManager.tasks
    init { loadChats() }
    fun loadChats(offset: Int = 0, limit: Int = 20) { viewModelScope.launch { _chats.value = dao.getChatsPaged(limit, offset) } }
    fun createChat(title: String) { viewModelScope.launch { dao.insertChat(Chat(title = title)); loadChats() } }
    fun deleteChat(id: String) { viewModelScope.launch { dao.deleteChat(id); loadChats() } }
    fun search(query: String, token: String? = null) { viewModelScope.launch { /* UI handles filtering */ } }            val settings = MutableStateFlow(AppSettings())
    data class AppSettings(val theme: String = "SYSTEM", val useRam: Boolean = true, val hfToken: String = "", val nCtx: Int = 4096, val temp: Float = 0.7f)
}
