package com.example.romai
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp class App : Application()
