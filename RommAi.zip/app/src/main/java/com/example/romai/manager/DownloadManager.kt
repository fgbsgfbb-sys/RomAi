package com.example.romai.manager
import android.content.Context
import com.example.romai.data.remote.HfApi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import java.io.File        import java.io.RandomAccessFile
enum class DownloadState { IDLE, DOWNLOADING, PAUSED, COMPLETED, ERROR }
data class DownloadTask(val modelId: String, val url: String, val filename: String, var state: DownloadState = DownloadState.IDLE, var progress: Float = 0f, var downloaded: Long = 0L, var total: Long = -1L)
class DownloadManager(private val ctx: Context, private val api: HfApi) {
    private val client = OkHttpClient.Builder().build()
    private val _tasks = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasks: StateFlow<List<DownloadTask>> = _tasks.asStateFlow()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    fun start(task: DownloadTask) {
        _tasks.value = _tasks.value.toMutableList().apply { add(task) }
        scope.launch {
            try {
                val dir = File(ctx.filesDir, "models"); dir.mkdirs()
                val file = File(dir, task.filename)
                task.state = DownloadState.DOWNLOADING
                while(task.state == DownloadState.DOWNLOADING) {
                    val range = if(file.exists()) "bytes=${file.length()}-" else null
                    val resp = api.downloadFile(task.url, range)
                    if(resp.isSuccessful && resp.body() != null) {
                        task.total = resp.headers()["Content-Range"]?.split('/')?.lastOrNull()?.toLongOrNull() ?: -1
                        val raf = RandomAccessFile(file, "rw")
                        if(range != null) raf.seek(file.length())
                        val input = resp.body()!!.byteStream()
                        val buffer = ByteArray(8192)
                        var len: Int
                        while(input.read(buffer).also { len = it } != -1 && task.state == DownloadState.DOWNLOADING) {
                            raf.write(buffer, 0, len)
                            task.downloaded += len
                            task.progress = if(task.total > 0) task.downloaded.toFloat() / task.total else 0f
                        }
                        raf.close(); input.close()
                        if(task.state == DownloadState.DOWNLOADING) task.state = DownloadState.COMPLETED
                    } else { task.state = DownloadState.ERROR }
                }
            } catch(e: Exception) { task.state = DownloadState.ERROR }
            _tasks.value = _tasks.value
        }
    }
    fun pause(id: String) { _tasks.value.find { it.modelId == id && it.state == DownloadState.DOWNLOADING }?.state = DownloadState.PAUSED; _tasks.value = _tasks.value }
    fun resume(id: String) { _tasks.value.find { it.modelId == id && it.state == DownloadState.PAUSED }?.state = DownloadState.DOWNLOADING; _tasks.value = _tasks.value }
    fun cancel(id: String) { _tasks.value.find { it.modelId == id }?.state = DownloadState.IDLE; _tasks.value = _tasks.value; File(ctx.filesDir, "models/${_tasks.value.find { it.modelId == id }?.filename}").delete() }
}
