package com.example.romai.presentation
import android.os.Bundle; import androidx.activity.ComponentActivity; import androidx.activity.compose.setContent; import androidx.compose.foundation.layout.*; import androidx.compose.material3.*; import androidx.compose.runtime.*; import androidx.compose.ui.Alignment; import androidx.compose.ui.Modifier; import androidx.compose.ui.text.font.FontWeight; import androidx.compose.ui.unit.dp; import androidx.compose.ui.unit.sp; import androidx.hilt.navigation.compose.hiltViewModel; import androidx.navigation.compose.*; import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = hiltViewModel()
            val nav = rememberNavController()
            RomAIAppTheme {
                Surface { NavHost(navController = nav, startDestination = "home") {
                    composable("home") { HomeScreen(vm, nav) }
                    composable("chat/{id}") { back -> ChatScreen(back.arguments?.getString("id") ?: "", vm, nav) }
                    composable("settings") { SettingsScreen(vm, nav) }
                }}
            }
        }
    }
}
@Composable fun HomeScreen(vm: MainViewModel, nav: NavHostController) {
    val chats by vm.chats.collectAsState()
    val tasks by vm.downloadTasks.collectAsState()
    var search by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("RomAI", fontSize=22.sp, fontWeight=FontWeight.Bold) }, actions = { IconButton(onClick = { nav.navigate("settings") }) { Text("Ξ", fontSize=28.sp) } }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            OutlinedTextField(value=search, onValueChange={search=it}, modifier=Modifier.fillMaxWidth(), placeholder={Text("Динамический поиск: model Q2K")})
            Spacer(Modifier.height(12.dp))
            Text("Скачанные", fontWeight=FontWeight.Bold); chats.forEach { c -> Row(Modifier.fillMaxWidth().padding(vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(c.title, modifier=Modifier.weight(1f))
                Button(onClick={}) { Text("Запуск") }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick={}) { Text("⚙") }
                IconButton(onClick={ vm.deleteChat(c.id) }) { Text("⌫") }
            }}
            Divider(Modifier.padding(vertical=12.dp))
            Text("Рекомендуемые", fontWeight=FontWeight.Bold); Text("Qwen2.5-7B-Instruct-Q4"); Text("gemma-2-2b-it-q4")
            Spacer(Modifier.height(12.dp))
            Text("Избранное (Wishlist)", fontWeight=FontWeight.Bold)
            tasks.forEach { t -> Row(Modifier.fillMaxWidth().padding(vertical=4.dp), verticalAlignment=Alignment.CenterVertically) {
                Text(t.filename, modifier=Modifier.weight(1f))
                if(t.state.name == "PAUSED") { Button(onClick={}) { Text("▶") } } else if(t.state.name == "DOWNLOADING") { Button(onClick={}) { Text("⏸") } }
                if(t.state.name == "PAUSED" || t.state.name == "DOWNLOADING") { Spacer(Modifier.width(8.dp)); Button(onClick={}) { Text("Отмена") } }
                Spacer(Modifier.width(12.dp)); Column(horizontalAlignment=Alignment.End) { Text("${(t.progress*100).toInt()}%"); Text("ℹ") }
            }}
        }            }
}
@Composable fun ChatScreen(chatId: String, vm: MainViewModel, nav: NavHostController) { Scaffold(topBar = { TopAppBar(title={Text("Чат")}, navigationIcon={IconButton(onClick={nav.popBackStack()}){Text("←")}}) }) { } }
@Composable fun SettingsScreen(vm: MainViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsState()
    Scaffold(topBar = { TopAppBar(title={Text("Настройки")}, navigationIcon={IconButton(onClick={nav.popBackStack()}){Text("←")}}) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Тема"); Text(settings.theme) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Режим памяти (ОЗУ/ПЗУ)"); Switch(checked=settings.useRam, onCheckedChange={}) }
            OutlinedTextField(value=settings.hfToken, onValueChange={}, label={Text("HuggingFace Token")}, modifier=Modifier.fillMaxWidth())
        }
    }
}
@Composable fun RomAIAppTheme(content: @Composable () -> Unit) { MaterialTheme { content() } }
