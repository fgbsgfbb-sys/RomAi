package com.example.romai.di
import android.content.Context
import com.example.romai.data.local.AppDatabase
import com.example.romai.data.local.ChatDao
import com.example.romai.data.remote.HfApi
import com.example.romai.data.repository.ModelRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class) object AppModule {
    @Provides @Singleton fun provideHfApi(): HfApi = Retrofit.Builder().baseUrl("https://huggingface.co/api/").addConverterFactory(GsonConverterFactory.create()).build().create(HfApi::class.java)
    @Provides @Singleton fun provideDatabase(@ApplicationContext ctx: Context) = AppDatabase.getDatabase(ctx)
    @Provides @Singleton fun provideChatDao(db: AppDatabase) = db.chatDao()
    @Provides @Singleton fun provideModelRepository(api: HfApi, dao: ChatDao, @ApplicationContext ctx: Context) = ModelRepository(api, dao, ctx)
}
