package com.example.romai.data.local        import androidx.room.*
@Entity(tableName = "chats") data class Chat(@PrimaryKey val id: String = java.util.UUID.randomUUID().toString(), val title: String, val created: Long = System.currentTimeMillis())
@Entity(tableName = "messages", foreignKeys = [ForeignKey(entity = Chat::class, parentColumns = ["id"], childColumns = ["chatId"], onDelete = ForeignKey.CASCADE)]) data class Message(@PrimaryKey val id: String = java.util.UUID.randomUUID().toString(), val chatId: String, val role: String, val content: String, val timestamp: Long = System.currentTimeMillis())
@Dao interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY created DESC LIMIT :limit OFFSET :offset") fun getChatsPaged(limit: Int, offset: Int): List<Chat>
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp ASC") fun getMessages(chatId: String): List<Message>
    @Insert fun insertChat(chat: Chat): Long
    @Insert fun insertMessage(msg: Message)
    @Query("DELETE FROM chats WHERE id = :id") fun deleteChat(id: String)
    @Query("DELETE FROM messages WHERE chatId = :id") fun clearChat(id: String)
}
@Database(entities = [Chat::class, Message::class], version = 1) abstract class AppDatabase : RoomDatabase() { abstract fun chatDao(): ChatDao; companion object { @Volatile private var INSTANCE: AppDatabase? = null; fun getDatabase(ctx: android.content.Context) = INSTANCE ?: synchronized(this) { val i = Room.databaseBuilder(ctx, AppDatabase::class.java, "romai_db").build(); INSTANCE = i; i } } }
