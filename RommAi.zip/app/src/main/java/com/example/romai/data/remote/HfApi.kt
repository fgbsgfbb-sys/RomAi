package com.example.romai.data.remote
import retrofit2.http.GET; import retrofit2.http.Header; import retrofit2.http.Query; import retrofit2.http.Url; import okhttp3.ResponseBody; import retrofit2.Response
data class HfModel(val id: String, val modelId: String, val author: String, val downloads: Long, val tags: List<String>, val pipeline_tag: String?)
interface HfApi {
    @GET("models") suspend fun search(@Query("search") q: String, @Query("limit") limit: Int, @Header("Authorization") token: String? = null): List<HfModel>
    @GET suspend fun downloadFile(@Url url: String, @Header("Range") range: String? = null): Response<ResponseBody>
}
