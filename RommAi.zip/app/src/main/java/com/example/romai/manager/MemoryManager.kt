package com.example.romai.manager
import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.channels.FileChannel        import java.nio.file.StandardOpenOption
import javax.inject.Inject
import javax.inject.Singleton
@Singleton class MemoryManager @Inject constructor(@javax.inject.Named("app_context") private val ctx: Context) {
    private val memDir = File(ctx.filesDir, "memory_cache"); init { memDir.mkdirs() }
    fun prepareMemoryFile(modelName: String, useStorage: Boolean): String {
        val file = File(memDir, "${modelName.replace("[^a-zA-Z0-9]".toRegex(), "_")}.mem")
        if(!file.exists()) file.createNewFile()
        if(useStorage) {
            // Pre-allocate for storage mode (simulates offloading)
            FileChannel.open(file.toPath(), StandardOpenOption.WRITE).force(true)
        }
        return file.absolutePath
    }
    fun clearMemory() { memDir.listFiles()?.forEach { it.delete() } }
}
