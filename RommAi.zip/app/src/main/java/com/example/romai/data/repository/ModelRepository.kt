package com.example.romai.data.repository
import android.content.Context
import com.example.romai.data.local.ChatDao
import com.example.romai.data.remote.HfApi
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
class ModelRepository @Inject constructor(private val api: HfApi, private val chatDao: ChatDao, @ApplicationContext private val ctx: Context) {
    suspend fun searchModels(query: String, token: String? = null) = api.search(query, 50, token?.let { "Bearer $it" })
    fun dynamicFilter(models: List<com.example.romai.data.remote.HfModel>, query: String): List<com.example.romai.data.remote.HfModel> {
        val terms = query.split(" ").filter { it.isNotBlank() }.map { it.lowercase() }
        return models.filter { m -> terms.all { t -> m.id.lowercase().contains(t) || m.author.lowercase().contains(t) || (m.tags?.any { it.lowercase().contains(t) } == true) } }
    }
}
