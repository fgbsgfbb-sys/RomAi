#include <jni.h>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <android/log.h>

#include "llama.cpp/include/llama.h"
#include "llama.cpp/common/common.h"

#define TAG "RomAI-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::atomic<bool> g_stop_generation(false);
static JavaVM* g_jvm = nullptr;
static jobject g_callback_obj = nullptr;
static jmethodID g_callback_method = nullptr;

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_jvm = vm;
    llama_backend_init();
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved) {
    llama_backend_free();
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_romai_app_data_LlamaEngine_loadModel(
        JNIEnv* env,
        jobject thiz,
        jstring model_path,
        jint context_size,
        jint threads,
        jboolean use_mmap,
        jboolean use_mlock) {

    if (g_model != nullptr) {
        llama_free(g_ctx);
        llama_free_model(g_model);
        g_model = nullptr;
        g_ctx = nullptr;
    }

    const char* path = env->GetStringUTFChars(model_path, nullptr);
    LOGI("Loading model from: %s", path);

    llama_model_params model_params = llama_model_default_params();
    model_params.use_mmap = use_mmap;
    model_params.use_mlock = use_mlock;
    model_params.n_gpu_layers = 0; // CPU only on Android

    g_model = llama_load_model_from_file(path, model_params);
    env->ReleaseStringUTFChars(model_path, path);

    if (g_model == nullptr) {
        LOGE("Failed to load model");
        return JNI_FALSE;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = context_size;
    ctx_params.n_threads = threads;
    ctx_params.n_threads_batch = threads;

    g_ctx = llama_new_context_with_model(g_model, ctx_params);

    if (g_ctx == nullptr) {
        LOGE("Failed to create context");
        llama_free_model(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    LOGI("Model loaded successfully");
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_romai_app_data_LlamaEngine_unloadModel(JNIEnv* env, jobject thiz) {
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_free_model(g_model);
        g_model = nullptr;
    }
    LOGI("Model unloaded");
}

JNIEXPORT jstring JNICALL
Java_com_romai_app_data_LlamaEngine_generate(
        JNIEnv* env,
        jobject thiz,
        jstring prompt,
        jint max_tokens,
        jfloat temperature,
        jfloat top_p,
        jint top_k,
        jfloat repeat_penalty,
        jobject token_callback) {

    if (g_model == nullptr || g_ctx == nullptr) {
        return env->NewStringUTF("[Error: Model not loaded]");
    }

    g_stop_generation = false;

    const char* prompt_str = env->GetStringUTFChars(prompt, nullptr);
    std::string prompt_text(prompt_str);
    env->ReleaseStringUTFChars(prompt, prompt_str);

    // Tokenize
    std::vector<llama_token> tokens_list;
    tokens_list.resize(prompt_text.size() + 32);
    int n_tokens = llama_tokenize(
        g_model,
        prompt_text.c_str(),
        prompt_text.size(),
        tokens_list.data(),
        tokens_list.size(),
        true,
        true
    );

    if (n_tokens < 0) {
        return env->NewStringUTF("[Error: Tokenization failed]");
    }
    tokens_list.resize(n_tokens);

    // Get callback class and method
    jclass callback_class = env->GetObjectClass(token_callback);
    jmethodID on_token = env->GetMethodID(callback_class, "onToken", "(Ljava/lang/String;)V");

    llama_kv_cache_clear(g_ctx);

    // Batch decode
    llama_batch batch = llama_batch_get_one(tokens_list.data(), tokens_list.size());
    if (llama_decode(g_ctx, batch) != 0) {
        return env->NewStringUTF("[Error: Decode failed]");
    }

    std::string result;
    int n_cur = tokens_list.size();

    // Sampling params
    auto sparams = llama_sampler_chain_default_params();
    llama_sampler* sampler = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(top_k));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(top_p, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    while (n_cur < max_tokens && !g_stop_generation) {
        llama_token token_id = llama_sampler_sample(sampler, g_ctx, -1);

        if (llama_token_is_eog(g_model, token_id)) {
            break;
        }

        char buf[256];
        int n = llama_token_to_piece(g_model, token_id, buf, sizeof(buf), 0, true);
        if (n > 0) {
            std::string piece(buf, n);
            result += piece;

            // Callback to Kotlin with each token
            jstring jtoken = env->NewStringUTF(piece.c_str());
            env->CallVoidMethod(token_callback, on_token, jtoken);
            env->DeleteLocalRef(jtoken);
        }

        llama_batch next = llama_batch_get_one(&token_id, 1);
        if (llama_decode(g_ctx, next) != 0) {
            break;
        }
        n_cur++;
    }

    llama_sampler_free(sampler);
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT void JNICALL
Java_com_romai_app_data_LlamaEngine_stopGeneration(JNIEnv* env, jobject thiz) {
    g_stop_generation = true;
}

JNIEXPORT jboolean JNICALL
Java_com_romai_app_data_LlamaEngine_isModelLoaded(JNIEnv* env, jobject thiz) {
    return (g_model != nullptr && g_ctx != nullptr) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_romai_app_data_LlamaEngine_getModelInfo(JNIEnv* env, jobject thiz) {
    if (g_model == nullptr) {
        return env->NewStringUTF("{}");
    }

    char buf[2048];
    llama_model_meta_val_str(g_model, "general.name", buf, sizeof(buf));
    std::string name(buf);

    int n_params = llama_model_n_params(g_model);
    int ctx_size = llama_n_ctx(g_ctx);

    std::string info = "{\"name\":\"" + name + "\","
        "\"n_params\":" + std::to_string(n_params) + ","
        "\"ctx_size\":" + std::to_string(ctx_size) + "}";

    return env->NewStringUTF(info.c_str());
}

} // extern "C"
