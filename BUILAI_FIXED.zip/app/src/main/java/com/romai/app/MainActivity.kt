package com.romai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.romai.app.ui.screens.ChatScreen
import com.romai.app.ui.screens.ChatsScreen
import com.romai.app.ui.screens.ModelsScreen
import com.romai.app.ui.screens.SettingsScreen
import com.romai.app.ui.theme.RomAITheme
import com.romai.app.ui.viewmodel.SettingsViewModel
import dagger.hilt.android.AndroidEntryPoint

sealed class Screen(val route: String) {
    object Chats : Screen("chats")
    object Chat : Screen("chat/{chatId}") {
        fun createRoute(chatId: String) = "chat/$chatId"
    }
    object Models : Screen("models")
    object Settings : Screen("settings")
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settingsVm: SettingsViewModel = hiltViewModel()
            val settings by settingsVm.settings.collectAsState()

            RomAITheme(language = settings.language) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Chats.route
                    ) {
                        composable(Screen.Chats.route) {
                            ChatsScreen(
                                onOpenChat = { chatId ->
                                    navController.navigate(Screen.Chat.createRoute(chatId))
                                },
                                onNavigateToModels = {
                                    navController.navigate(Screen.Models.route)
                                },
                                onNavigateToSettings = {
                                    navController.navigate(Screen.Settings.route)
                                }
                            )
                        }
                        composable(
                            route = Screen.Chat.route,
                            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
                        ) {
                            ChatScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.Models.route) {
                            ModelsScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.Settings.route) {
                            SettingsScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
