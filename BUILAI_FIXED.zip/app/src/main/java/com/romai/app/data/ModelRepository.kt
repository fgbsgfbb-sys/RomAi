package com.romai.app.data

import android.content.Context
import com.romai.app.data.model.ModelDao
import com.romai.app.data.model.ModelEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val modelDao: ModelDao,
    private val hfApi: HuggingFaceApi,
    private val settings: SettingsRepository
) {
    val localModels: Flow<List<ModelEntity>> = modelDao.getAllModels()

    fun getModelsDir(): File {
        val dir = File(context.filesDir, "models")
        dir.mkdirs()
        return dir
    }

    suspend fun searchHuggingFace(query: String): List<HFSearchResult> {
        return hfApi.searchModels(query)
    }

    suspend fun getHFModelInfo(repoId: String): HFModelInfo {
        return hfApi.getModelInfo(repoId)
    }

    fun getGgufFiles(modelInfo: HFModelInfo): List<HFFileSibling> {
        return modelInfo.siblings.filter { it.filename.endsWith(".gguf") }
    }

    fun startDownload(repoId: String, filename: String, sibling: HFFileSibling) {
        val url = HuggingFaceApi.getDownloadUrl(repoId, filename)
        val destFile = File(getModelsDir(), filename)
        DownloadService.startDownload(context, url, destFile.absolutePath, repoId, filename)
    }

    suspend fun registerDownloadedModel(
        repoId: String,
        filename: String,
        modelInfo: HFModelInfo,
        sibling: HFFileSibling
    ) {
        val file = File(getModelsDir(), filename)
        val fileSize = sibling.lfs?.size ?: sibling.size ?: file.length()

        // Parse params from filename e.g. "Qwen2.5-7B-Q4_K_M.gguf"
        val quantMatch = Regex("Q\\d+_K_[MS]|Q\\d+_\\d|Q\\d+").find(filename)
        val quantization = quantMatch?.value ?: "unknown"

        val paramMatch = Regex("(\\d+(\\.\\d+)?)[Bb]").find(filename)
        val params = paramMatch?.groupValues?.get(1)?.let { "${it}B" } ?: "?"

        val entity = ModelEntity(
            id = UUID.randomUUID().toString(),
            name = modelInfo.id.substringAfterLast("/"),
            filePath = file.absolutePath,
            fileSizeBytes = fileSize,
            parameterCount = params,
            author = modelInfo.author ?: repoId.substringBefore("/"),
            description = modelInfo.description ?: "",
            maxContextLength = 4096,
            quantization = quantization,
            hfRepoId = repoId
        )
        modelDao.insertModel(entity)
    }

    suspend fun deleteModel(model: ModelEntity) {
        File(model.filePath).delete()
        modelDao.deleteModel(model)
    }

    suspend fun getModelById(id: String): ModelEntity? = modelDao.getModelById(id)
}
