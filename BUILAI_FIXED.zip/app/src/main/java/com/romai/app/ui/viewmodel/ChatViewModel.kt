package com.romai.app.ui.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romai.app.data.*
import com.romai.app.data.model.ChatEntity
import com.romai.app.data.model.MessageEntity
import com.romai.app.data.model.ModelEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class ChatUiState(
    val chat: ChatEntity? = null,
    val messages: List<MessageEntity> = emptyList(),
    val model: ModelEntity? = null,
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val isModelLoading: Boolean = false,
    val streamingText: String = "",
    val error: String? = null
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val modelRepository: ModelRepository,
    private val settingsRepository: SettingsRepository,
    private val llamaEngine: LlamaEngine,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val chatId: String = savedStateHandle["chatId"] ?: ""

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val settings = settingsRepository.settings
    private var generationJob: Job? = null

    init {
        loadChat()
    }

    private fun loadChat() {
        viewModelScope.launch {
            chatRepository.getMessagesForChat(chatId).collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }
        viewModelScope.launch {
            val chat = chatRepository.getChatById(chatId) ?: return@launch
            _uiState.update { it.copy(chat = chat) }
            val model = modelRepository.getModelById(chat.modelId) ?: return@launch
            _uiState.update { it.copy(model = model) }
            loadModel(model)
        }
    }

    private fun loadModel(model: ModelEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isModelLoading = true, error = null) }
            val s = settings.first()
            val ok = llamaEngine.loadModelSuspend(
                modelPath = model.filePath,
                contextSize = s.contextSize,
                threads = s.threads,
                useMmap = s.useRomMode,
                useMlock = false
            )
            if (!ok) {
                _uiState.update { it.copy(isModelLoading = false, error = "Не удалось загрузить модель") }
            } else {
                _uiState.update { it.copy(isModelLoading = false) }
            }
        }
    }

    fun onInputChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isBlank() || _uiState.value.isGenerating) return

        viewModelScope.launch {
            _uiState.update { it.copy(inputText = "", isGenerating = true, streamingText = "", error = null) }

            // Save user message
            chatRepository.addMessage(chatId, "user", text)

            // Build prompt from history
            val s = settings.first()
            val history = chatRepository.getMessagesSync(chatId)
            val chat = _uiState.value.chat
            val prompt = buildPrompt(history, chat?.systemPrompt ?: s.systemPrompt)

            // Stream generation
            var fullResponse = ""
            generationJob = launch(Dispatchers.IO) {
                llamaEngine.generateStream(
                    prompt = prompt,
                    maxTokens = s.maxTokens,
                    temperature = s.temperature,
                    topP = s.topP,
                    topK = s.topK,
                    repeatPenalty = s.repeatPenalty
                ).collect { token ->
                    fullResponse += token
                    _uiState.update { it.copy(streamingText = fullResponse) }
                }
            }
            generationJob?.join()

            // Save assistant response
            if (fullResponse.isNotEmpty()) {
                chatRepository.addMessage(chatId, "assistant", fullResponse)
            }
            _uiState.update { it.copy(isGenerating = false, streamingText = "") }
        }
    }

    fun stopGeneration() {
        llamaEngine.stopGeneration()
        generationJob?.cancel()
        viewModelScope.launch {
            val streaming = _uiState.value.streamingText
            if (streaming.isNotEmpty()) {
                chatRepository.addMessage(chatId, "assistant", streaming)
            }
            _uiState.update { it.copy(isGenerating = false, streamingText = "") }
        }
    }

    private fun buildPrompt(messages: List<MessageEntity>, systemPrompt: String): String {
        val sb = StringBuilder()
        if (systemPrompt.isNotEmpty()) {
            sb.append("<|system|>\n$systemPrompt\n")
        }
        messages.forEach { msg ->
            val role = if (msg.role == "user") "<|user|>" else "<|assistant|>"
            sb.append("$role\n${msg.content}\n")
        }
        sb.append("<|assistant|>\n")
        return sb.toString()
    }

    override fun onCleared() {
        super.onCleared()
        // Don't unload model — keep for other chats
    }
}
