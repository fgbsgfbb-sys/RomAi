package com.romai.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romai.app.data.AppSettings
import com.romai.app.data.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setLanguage(lang: String) = viewModelScope.launch { settingsRepository.updateLanguage(lang) }
    fun setTemperature(v: Float) = viewModelScope.launch { settingsRepository.updateTemperature(v) }
    fun setTopP(v: Float) = viewModelScope.launch { settingsRepository.updateTopP(v) }
    fun setTopK(v: Int) = viewModelScope.launch { settingsRepository.updateTopK(v) }
    fun setRepeatPenalty(v: Float) = viewModelScope.launch { settingsRepository.updateRepeatPenalty(v) }
    fun setMaxTokens(v: Int) = viewModelScope.launch { settingsRepository.updateMaxTokens(v) }
    fun setContextSize(v: Int) = viewModelScope.launch { settingsRepository.updateContextSize(v) }
    fun setThreads(v: Int) = viewModelScope.launch { settingsRepository.updateThreads(v) }
    fun setUseRomMode(v: Boolean) = viewModelScope.launch { settingsRepository.updateUseRomMode(v) }
    fun setRomBufferGb(v: Float) = viewModelScope.launch { settingsRepository.updateRomBufferGb(v) }
    fun setModelStoragePath(v: String) = viewModelScope.launch { settingsRepository.updateModelStoragePath(v) }
    fun setSystemPrompt(v: String) = viewModelScope.launch { settingsRepository.updateSystemPrompt(v) }
}
