package com.romai.app.data

import com.romai.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val chatDao: ChatDao,
    private val messageDao: MessageDao
) {
    val allChats: Flow<List<ChatEntity>> = chatDao.getAllChats()

    fun getMessagesForChat(chatId: String): Flow<List<MessageEntity>> =
        messageDao.getMessagesForChat(chatId)

    suspend fun createChat(modelId: String, title: String, systemPrompt: String = ""): ChatEntity {
        val chat = ChatEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            modelId = modelId,
            systemPrompt = systemPrompt
        )
        chatDao.insertChat(chat)
        return chat
    }

    suspend fun renameChat(chat: ChatEntity, newTitle: String) {
        chatDao.updateChat(chat.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteChat(chat: ChatEntity) = chatDao.deleteChat(chat)

    suspend fun deleteChats(ids: List<String>) = chatDao.deleteChatsById(ids)

    suspend fun deleteAllChats() = chatDao.deleteAllChats()

    suspend fun addMessage(chatId: String, role: String, content: String): MessageEntity {
        val msg = MessageEntity(
            id = UUID.randomUUID().toString(),
            chatId = chatId,
            role = role,
            content = content
        )
        messageDao.insertMessage(msg)
        chatDao.updateChatTime(chatId)
        return msg
    }

    suspend fun updateMessage(message: MessageEntity) = messageDao.insertMessage(message)

    suspend fun getMessagesSync(chatId: String): List<MessageEntity> =
        messageDao.getMessagesForChatSync(chatId)

    suspend fun getChatById(id: String): ChatEntity? = chatDao.getChatById(id)
}
