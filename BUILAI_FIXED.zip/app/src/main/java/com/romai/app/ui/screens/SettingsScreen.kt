package com.romai.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.romai.app.ui.viewmodel.SettingsViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    vm: SettingsViewModel = hiltViewModel()
) {
    val s by vm.settings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, "Назад")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {

            // ─── Language ────────────────────────────────────────────────────
            item {
                SectionHeader("Язык / Language")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = s.language == "ru",
                        onClick = { vm.setLanguage("ru") },
                        label = { Text("Русский") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = s.language == "en",
                        onClick = { vm.setLanguage("en") },
                        label = { Text("English") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ─── Execution Mode ───────────────────────────────────────────────
            item {
                SectionHeader("Режим выполнения")
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("ROM режим (mmap)", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (s.useRomMode) "Модель читается с ПЗУ (не загружается в ОЗУ)"
                                    else "Модель загружается полностью в ОЗУ",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                            Switch(checked = s.useRomMode, onCheckedChange = vm::setUseRomMode)
                        }
                        if (s.useRomMode) {
                            SliderRow(
                                label = "Буфер для модели",
                                value = s.romBufferSizeGb,
                                valueLabel = "%.1f ГБ".format(s.romBufferSizeGb),
                                range = 1f..12f,
                                steps = 21,
                                onValueChange = vm::setRomBufferGb
                            )
                        }
                    }
                }
            }

            // ─── Generation ────────────────────────────────────────────────────
            item {
                SectionHeader("Генерация")
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {

                        SliderRow(
                            label = "Температура",
                            value = s.temperature,
                            valueLabel = "%.2f".format(s.temperature),
                            range = 0f..2f,
                            steps = 39,
                            onValueChange = vm::setTemperature
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Top-P",
                            value = s.topP,
                            valueLabel = "%.2f".format(s.topP),
                            range = 0f..1f,
                            steps = 19,
                            onValueChange = vm::setTopP
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Top-K",
                            value = s.topK.toFloat(),
                            valueLabel = "${s.topK}",
                            range = 1f..200f,
                            steps = 198,
                            onValueChange = { vm.setTopK(it.roundToInt()) }
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Штраф повторения",
                            value = s.repeatPenalty,
                            valueLabel = "%.2f".format(s.repeatPenalty),
                            range = 1f..2f,
                            steps = 19,
                            onValueChange = vm::setRepeatPenalty
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Макс. токенов",
                            value = s.maxTokens.toFloat(),
                            valueLabel = "${s.maxTokens}",
                            range = 64f..4096f,
                            steps = 62,
                            onValueChange = { vm.setMaxTokens(it.roundToInt()) }
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Размер контекста",
                            value = s.contextSize.toFloat(),
                            valueLabel = "${s.contextSize}",
                            range = 512f..8192f,
                            steps = 14,
                            onValueChange = { vm.setContextSize(it.roundToInt()) }
                        )
                        HorizontalDivider()
                        SliderRow(
                            label = "Потоки CPU",
                            value = s.threads.toFloat(),
                            valueLabel = "${s.threads}",
                            range = 1f..8f,
                            steps = 6,
                            onValueChange = { vm.setThreads(it.roundToInt()) }
                        )
                    }
                }
            }

            // ─── System Prompt ────────────────────────────────────────────────
            item {
                SectionHeader("Системный промпт по умолчанию")
                var localPrompt by remember(s.systemPrompt) { mutableStateOf(s.systemPrompt) }
                OutlinedTextField(
                    value = localPrompt,
                    onValueChange = { localPrompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 6,
                    placeholder = { Text("You are a helpful AI assistant.") }
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { vm.setSystemPrompt(localPrompt) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Сохранить промпт")
                }
            }

            // ─── Storage Path ─────────────────────────────────────────────────
            item {
                SectionHeader("Хранилище моделей")
                var localPath by remember(s.modelStoragePath) { mutableStateOf(s.modelStoragePath) }
                OutlinedTextField(
                    value = localPath,
                    onValueChange = { localPath = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Путь по умолчанию (внутренняя память)") },
                    singleLine = true,
                    label = { Text("Путь к папке") }
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { vm.setModelStoragePath(localPath) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Сохранить путь")
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    valueLabel: String,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(
                valueLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            steps = steps,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
