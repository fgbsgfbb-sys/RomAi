package com.romai.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import javax.inject.Inject

data class DownloadProgress(
    val modelId: String,
    val filename: String,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val isComplete: Boolean = false,
    val error: String? = null
) {
    val progressPercent: Int get() =
        if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt() else 0
}

@AndroidEntryPoint
class DownloadService : Service() {

    @Inject lateinit var okHttpClient: OkHttpClient

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        const val CHANNEL_ID = "romai_download"
        const val NOTIF_ID = 1001
        const val ACTION_DOWNLOAD = "com.romai.app.DOWNLOAD"
        const val EXTRA_URL = "url"
        const val EXTRA_DEST = "dest"
        const val EXTRA_MODEL_ID = "model_id"
        const val EXTRA_FILENAME = "filename"

        private val _progress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
        val progress: StateFlow<Map<String, DownloadProgress>> = _progress

        fun startDownload(context: Context, url: String, destPath: String, modelId: String, filename: String) {
            val intent = Intent(context, DownloadService::class.java).apply {
                action = ACTION_DOWNLOAD
                putExtra(EXTRA_URL, url)
                putExtra(EXTRA_DEST, destPath)
                putExtra(EXTRA_MODEL_ID, modelId)
                putExtra(EXTRA_FILENAME, filename)
            }
            context.startForegroundService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Подготовка загрузки..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DOWNLOAD) {
            val url = intent.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
            val dest = intent.getStringExtra(EXTRA_DEST) ?: return START_NOT_STICKY
            val modelId = intent.getStringExtra(EXTRA_MODEL_ID) ?: return START_NOT_STICKY
            val filename = intent.getStringExtra(EXTRA_FILENAME) ?: return START_NOT_STICKY

            serviceScope.launch {
                downloadFile(url, dest, modelId, filename)
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun downloadFile(url: String, destPath: String, modelId: String, filename: String) {
        try {
            val request = Request.Builder().url(url).build()
            val response = okHttpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                updateProgress(modelId, filename, 0, 0, error = "HTTP ${response.code}")
                return
            }

            val totalBytes = response.body?.contentLength() ?: -1
            val destFile = File(destPath)
            destFile.parentFile?.mkdirs()

            var bytesRead = 0L
            response.body?.byteStream()?.use { input ->
                destFile.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        bytesRead += read
                        updateProgress(modelId, filename, bytesRead, totalBytes)
                        updateNotification("$filename: ${bytesRead * 100 / maxOf(totalBytes, 1)}%")
                    }
                }
            }

            updateProgress(modelId, filename, bytesRead, totalBytes, isComplete = true)
            updateNotification("$filename загружен!")

        } catch (e: Exception) {
            updateProgress(modelId, filename, 0, 0, error = e.message ?: "Unknown error")
        }
    }

    private fun updateProgress(
        modelId: String,
        filename: String,
        bytes: Long,
        total: Long,
        isComplete: Boolean = false,
        error: String? = null
    ) {
        val current = _progress.value.toMutableMap()
        current[modelId] = DownloadProgress(modelId, filename, bytes, total, isComplete, error)
        _progress.value = current
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Загрузка моделей",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RomAI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
