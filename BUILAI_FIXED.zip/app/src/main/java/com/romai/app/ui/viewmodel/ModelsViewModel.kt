package com.romai.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romai.app.data.*
import com.romai.app.data.model.ModelEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HFModelUiItem(
    val repoId: String,
    val name: String,
    val author: String,
    val downloads: Int,
    val tags: List<String>,
    val ggufFiles: List<HFFileSibling> = emptyList(),
    val isExpanded: Boolean = false,
    val isLoadingFiles: Boolean = false
)

data class ModelsUiState(
    val localModels: List<ModelEntity> = emptyList(),
    val searchQuery: String = "",
    val searchResults: List<HFModelUiItem> = emptyList(),
    val isSearching: Boolean = false,
    val downloadProgress: Map<String, DownloadProgress> = emptyMap(),
    val error: String? = null,
    val selectedLocalModel: ModelEntity? = null,
    val activeModelId: String = ""
)

@HiltViewModel
class ModelsViewModel @Inject constructor(
    private val modelRepository: ModelRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ModelsUiState())
    val uiState: StateFlow<ModelsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            modelRepository.localModels.collect { models ->
                _uiState.update { it.copy(localModels = models) }
            }
        }
        viewModelScope.launch {
            DownloadService.progress.collect { progress ->
                _uiState.update { it.copy(downloadProgress = progress) }
                // Auto-register completed downloads
                progress.values.filter { it.isComplete }.forEach { dp ->
                    handleDownloadComplete(dp)
                }
            }
        }
        viewModelScope.launch {
            settingsRepository.settings.collect { s ->
                _uiState.update { it.copy(activeModelId = s.activeModelId) }
            }
        }
    }

    private suspend fun handleDownloadComplete(dp: DownloadProgress) {
        val existing = _uiState.value.localModels.any { it.hfRepoId == dp.modelId }
        if (!existing) {
            try {
                val modelInfo = modelRepository.getHFModelInfo(dp.modelId)
                val sibling = HFFileSibling(dp.filename, dp.totalBytes)
                modelRepository.registerDownloadedModel(dp.modelId, dp.filename, modelInfo, sibling)
            } catch (_: Exception) {}
        }
    }

    fun onSearchQueryChange(q: String) {
        _uiState.update { it.copy(searchQuery = q) }
    }

    fun search() {
        val q = _uiState.value.searchQuery.trim()
        if (q.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, error = null) }
            try {
                val results = modelRepository.searchHuggingFace(q)
                _uiState.update {
                    it.copy(
                        isSearching = false,
                        searchResults = results.map { r ->
                            HFModelUiItem(
                                repoId = r.id,
                                name = r.id.substringAfterLast("/"),
                                author = r.author ?: r.id.substringBefore("/"),
                                downloads = r.downloads,
                                tags = r.tags
                            )
                        }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isSearching = false, error = e.message) }
            }
        }
    }

    fun expandModel(repoId: String) {
        viewModelScope.launch {
            _uiState.update { state ->
                state.copy(searchResults = state.searchResults.map {
                    if (it.repoId == repoId) it.copy(isExpanded = !it.isExpanded, isLoadingFiles = !it.isExpanded && it.ggufFiles.isEmpty())
                    else it
                })
            }
            val item = _uiState.value.searchResults.find { it.repoId == repoId } ?: return@launch
            if (item.isExpanded && item.ggufFiles.isEmpty()) {
                try {
                    val info = modelRepository.getHFModelInfo(repoId)
                    val files = modelRepository.getGgufFiles(info)
                    _uiState.update { state ->
                        state.copy(searchResults = state.searchResults.map {
                            if (it.repoId == repoId) it.copy(ggufFiles = files, isLoadingFiles = false)
                            else it
                        })
                    }
                } catch (e: Exception) {
                    _uiState.update { state ->
                        state.copy(
                            searchResults = state.searchResults.map {
                                if (it.repoId == repoId) it.copy(isLoadingFiles = false) else it
                            },
                            error = e.message
                        )
                    }
                }
            }
        }
    }

    fun downloadFile(repoId: String, sibling: HFFileSibling) {
        modelRepository.startDownload(repoId, sibling.filename, sibling)
    }

    fun deleteModel(model: ModelEntity) {
        viewModelScope.launch {
            modelRepository.deleteModel(model)
            if (_uiState.value.activeModelId == model.id) {
                settingsRepository.updateActiveModelId("")
            }
        }
    }

    fun setActiveModel(modelId: String) {
        viewModelScope.launch {
            settingsRepository.updateActiveModelId(modelId)
        }
    }

    fun selectLocalModel(model: ModelEntity?) {
        _uiState.update { it.copy(selectedLocalModel = model) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }
}
