package com.romai.app.di

import android.content.Context
import androidx.room.Room
import com.romai.app.data.*
import com.romai.app.data.model.RomAIDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): RomAIDatabase =
        Room.databaseBuilder(ctx, RomAIDatabase::class.java, "romai.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideModelDao(db: RomAIDatabase) = db.modelDao()
    @Provides fun provideChatDao(db: RomAIDatabase) = db.chatDao()
    @Provides fun provideMessageDao(db: RomAIDatabase) = db.messageDao()

    @Provides @Singleton
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    @Provides @Singleton
    fun provideHuggingFaceApi(okHttpClient: OkHttpClient): HuggingFaceApi =
        Retrofit.Builder()
            .baseUrl(HuggingFaceApi.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(HuggingFaceApi::class.java)
}
