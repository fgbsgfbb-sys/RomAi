package com.romai.app.data

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

interface TokenCallback {
    fun onToken(token: String)
}

@Singleton
class LlamaEngine @Inject constructor() {

    companion object {
        private const val TAG = "LlamaEngine"
        init {
            System.loadLibrary("romai-llm")
        }
    }

    // JNI native functions
    private external fun loadModel(
        modelPath: String,
        contextSize: Int,
        threads: Int,
        useMmap: Boolean,
        useMlock: Boolean
    ): Boolean

    private external fun unloadModel()

    private external fun generate(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        repeatPenalty: Float,
        tokenCallback: TokenCallback
    ): String

    external fun stopGeneration()
    external fun isModelLoaded(): Boolean
    external fun getModelInfo(): String

    fun loadModelSuspend(
        modelPath: String,
        contextSize: Int = 2048,
        threads: Int = 4,
        useMmap: Boolean = false,
        useMlock: Boolean = false
    ): Boolean {
        Log.i(TAG, "Loading model: $modelPath")
        return loadModel(modelPath, contextSize, threads, useMmap, useMlock)
    }

    fun generateStream(
        prompt: String,
        maxTokens: Int = 512,
        temperature: Float = 0.7f,
        topP: Float = 0.9f,
        topK: Int = 40,
        repeatPenalty: Float = 1.1f
    ): Flow<String> = flow {
        val callback = object : TokenCallback {
            // tokens emitted via flow below
        }
        // Use channel-based streaming
        val tokens = mutableListOf<String>()
        val done = java.util.concurrent.CountDownLatch(1)

        val streamCallback = object : TokenCallback {
            override fun onToken(token: String) {
                tokens.add(token)
            }
        }

        // Run in background, collect tokens
        val thread = Thread {
            generate(prompt, maxTokens, temperature, topP, topK, repeatPenalty, streamCallback)
            done.countDown()
        }
        thread.start()

        // Poll tokens
        var idx = 0
        while (!done.await(50, java.util.concurrent.TimeUnit.MILLISECONDS) || idx < tokens.size) {
            while (idx < tokens.size) {
                emit(tokens[idx++])
            }
        }
    }.flowOn(Dispatchers.IO)

    fun unload() {
        unloadModel()
    }
}
