package com.romai.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "romai_settings")

data class AppSettings(
    val language: String = "ru",          // "ru" or "en"
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val maxTokens: Int = 512,
    val contextSize: Int = 2048,
    val threads: Int = 4,
    val useRomMode: Boolean = true,        // TRUE = load to storage (ROM), FALSE = load to RAM
    val romBufferSizeGb: Float = 6.0f,     // GB allocated for model file
    val modelStoragePath: String = "",     // custom path for model storage
    val systemPrompt: String = "You are a helpful AI assistant.",
    val activeModelId: String = ""
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val store = context.dataStore

    companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_TEMPERATURE = floatPreferencesKey("temperature")
        val KEY_TOP_P = floatPreferencesKey("top_p")
        val KEY_TOP_K = intPreferencesKey("top_k")
        val KEY_REPEAT_PENALTY = floatPreferencesKey("repeat_penalty")
        val KEY_MAX_TOKENS = intPreferencesKey("max_tokens")
        val KEY_CONTEXT_SIZE = intPreferencesKey("context_size")
        val KEY_THREADS = intPreferencesKey("threads")
        val KEY_USE_ROM_MODE = booleanPreferencesKey("use_rom_mode")
        val KEY_ROM_BUFFER_GB = floatPreferencesKey("rom_buffer_gb")
        val KEY_MODEL_STORAGE_PATH = stringPreferencesKey("model_storage_path")
        val KEY_SYSTEM_PROMPT = stringPreferencesKey("system_prompt")
        val KEY_ACTIVE_MODEL_ID = stringPreferencesKey("active_model_id")
    }

    val settings: Flow<AppSettings> = store.data.map { prefs ->
        AppSettings(
            language = prefs[KEY_LANGUAGE] ?: "ru",
            temperature = prefs[KEY_TEMPERATURE] ?: 0.7f,
            topP = prefs[KEY_TOP_P] ?: 0.9f,
            topK = prefs[KEY_TOP_K] ?: 40,
            repeatPenalty = prefs[KEY_REPEAT_PENALTY] ?: 1.1f,
            maxTokens = prefs[KEY_MAX_TOKENS] ?: 512,
            contextSize = prefs[KEY_CONTEXT_SIZE] ?: 2048,
            threads = prefs[KEY_THREADS] ?: 4,
            useRomMode = prefs[KEY_USE_ROM_MODE] ?: true,
            romBufferSizeGb = prefs[KEY_ROM_BUFFER_GB] ?: 6.0f,
            modelStoragePath = prefs[KEY_MODEL_STORAGE_PATH] ?: "",
            systemPrompt = prefs[KEY_SYSTEM_PROMPT] ?: "You are a helpful AI assistant.",
            activeModelId = prefs[KEY_ACTIVE_MODEL_ID] ?: ""
        )
    }

    suspend fun updateLanguage(lang: String) = store.edit { it[KEY_LANGUAGE] = lang }
    suspend fun updateTemperature(v: Float) = store.edit { it[KEY_TEMPERATURE] = v }
    suspend fun updateTopP(v: Float) = store.edit { it[KEY_TOP_P] = v }
    suspend fun updateTopK(v: Int) = store.edit { it[KEY_TOP_K] = v }
    suspend fun updateRepeatPenalty(v: Float) = store.edit { it[KEY_REPEAT_PENALTY] = v }
    suspend fun updateMaxTokens(v: Int) = store.edit { it[KEY_MAX_TOKENS] = v }
    suspend fun updateContextSize(v: Int) = store.edit { it[KEY_CONTEXT_SIZE] = v }
    suspend fun updateThreads(v: Int) = store.edit { it[KEY_THREADS] = v }
    suspend fun updateUseRomMode(v: Boolean) = store.edit { it[KEY_USE_ROM_MODE] = v }
    suspend fun updateRomBufferGb(v: Float) = store.edit { it[KEY_ROM_BUFFER_GB] = v }
    suspend fun updateModelStoragePath(v: String) = store.edit { it[KEY_MODEL_STORAGE_PATH] = v }
    suspend fun updateSystemPrompt(v: String) = store.edit { it[KEY_SYSTEM_PROMPT] = v }
    suspend fun updateActiveModelId(v: String) = store.edit { it[KEY_ACTIVE_MODEL_ID] = v }
}
