package com.romai.app.data

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

// ─── API Models ───────────────────────────────────────────────────────────────

data class HFSearchResult(
    @SerializedName("id") val id: String,
    @SerializedName("modelId") val modelId: String? = null,
    @SerializedName("author") val author: String? = null,
    @SerializedName("downloads") val downloads: Int = 0,
    @SerializedName("likes") val likes: Int = 0,
    @SerializedName("tags") val tags: List<String> = emptyList(),
    @SerializedName("pipeline_tag") val pipelineTag: String? = null,
    @SerializedName("lastModified") val lastModified: String? = null
)

data class HFModelInfo(
    @SerializedName("id") val id: String,
    @SerializedName("author") val author: String? = null,
    @SerializedName("description") val description: String? = null,
    @SerializedName("tags") val tags: List<String> = emptyList(),
    @SerializedName("siblings") val siblings: List<HFFileSibling> = emptyList(),
    @SerializedName("cardData") val cardData: HFCardData? = null
)

data class HFFileSibling(
    @SerializedName("rfilename") val filename: String,
    @SerializedName("size") val size: Long? = null,
    @SerializedName("lfs") val lfs: HFLfsInfo? = null
)

data class HFLfsInfo(
    @SerializedName("size") val size: Long
)

data class HFCardData(
    @SerializedName("language") val language: List<String>? = null,
    @SerializedName("license") val license: String? = null,
    @SerializedName("base_model") val baseModel: String? = null
)

// ─── Retrofit Interface ───────────────────────────────────────────────────────

interface HuggingFaceApi {

    @GET("api/models")
    suspend fun searchModels(
        @Query("search") query: String,
        @Query("filter") filter: String = "gguf",
        @Query("limit") limit: Int = 20,
        @Query("sort") sort: String = "downloads",
        @Query("direction") direction: Int = -1
    ): List<HFSearchResult>

    @GET("api/models/{repoId}")
    suspend fun getModelInfo(
        @Path("repoId", encoded = true) repoId: String
    ): HFModelInfo

    companion object {
        const val BASE_URL = "https://huggingface.co/"
        fun getDownloadUrl(repoId: String, filename: String): String {
            return "https://huggingface.co/$repoId/resolve/main/$filename"
        }
    }
}
