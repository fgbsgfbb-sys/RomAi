package com.romai.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.romai.app.data.HFFileSibling
import com.romai.app.data.model.ModelEntity
import com.romai.app.ui.viewmodel.HFModelUiItem
import com.romai.app.ui.viewmodel.ModelsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(
    onNavigateBack: () -> Unit,
    vm: ModelsViewModel = hiltViewModel()
) {
    val state by vm.uiState.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text("Модели") },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, "Назад")
                        }
                    }
                )
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Локальные") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("HuggingFace") })
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> LocalModelsTab(
                    models = state.localModels,
                    activeModelId = state.activeModelId,
                    downloadProgress = state.downloadProgress,
                    onSetActive = vm::setActiveModel,
                    onDelete = vm::deleteModel
                )
                1 -> HuggingFaceTab(
                    query = state.searchQuery,
                    onQueryChange = vm::onSearchQueryChange,
                    onSearch = vm::search,
                    isSearching = state.isSearching,
                    results = state.searchResults,
                    downloadProgress = state.downloadProgress,
                    onExpand = vm::expandModel,
                    onDownload = { repoId, sibling -> vm.downloadFile(repoId, sibling) }
                )
            }

            state.error?.let {
                Snackbar(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp),
                    action = { TextButton(onClick = vm::dismissError) { Text("OK") } }
                ) { Text(it) }
            }
        }
    }
}

@Composable
private fun LocalModelsTab(
    models: List<ModelEntity>,
    activeModelId: String,
    downloadProgress: Map<String, Any>,
    onSetActive: (String) -> Unit,
    onDelete: (ModelEntity) -> Unit
) {
    if (models.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.outline)
                Text("Нет загруженных моделей", color = MaterialTheme.colorScheme.outline)
                Text("Используйте вкладку HuggingFace", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(models, key = { it.id }) { model ->
            ModelLocalCard(
                model = model,
                isActive = model.id == activeModelId,
                onSetActive = { onSetActive(model.id) },
                onDelete = { onDelete(model) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun ModelLocalCard(
    model: ModelEntity,
    isActive: Boolean,
    onSetActive: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text(model.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Column {
                Text("${model.parameterCount} • ${model.quantization} • ${formatSize(model.fileSizeBytes)}")
                Text("Автор: ${model.author}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                if (model.maxContextLength > 0)
                    Text("Контекст: ${model.maxContextLength} токенов", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        },
        leadingContent = {
            if (isActive) {
                Icon(Icons.Default.RadioButtonChecked, null, tint = MaterialTheme.colorScheme.primary)
            } else {
                Icon(Icons.Default.RadioButtonUnchecked, null)
            }
        },
        trailingContent = {
            Row {
                if (!isActive) {
                    IconButton(onClick = onSetActive) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Сделать активной", tint = MaterialTheme.colorScheme.primary)
                    }
                }
                IconButton(onClick = { showDeleteDialog = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    )

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Удалить модель?") },
            text = { Text("Файл модели будет удалён с устройства") },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Отмена") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HuggingFaceTab(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    isSearching: Boolean,
    results: List<HFModelUiItem>,
    downloadProgress: Map<String, Any>,
    onExpand: (String) -> Unit,
    onDownload: (String, HFFileSibling) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Поиск моделей GGUF...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onChangeAndSearch("", onQueryChange) }) {
                        Icon(Icons.Default.Clear, null)
                    }
                }
            },
            singleLine = true
        )

        Button(
            onClick = onSearch,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            enabled = query.isNotBlank() && !isSearching
        ) {
            if (isSearching) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
            }
            Text("Найти")
        }

        Spacer(Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(results, key = { it.repoId }) { item ->
                HFModelCard(
                    item = item,
                    downloadProgress = downloadProgress,
                    onExpand = { onExpand(item.repoId) },
                    onDownload = { sibling -> onDownload(item.repoId, sibling) }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun HFModelCard(
    item: HFModelUiItem,
    downloadProgress: Map<String, Any>,
    onExpand: () -> Unit,
    onDownload: (HFFileSibling) -> Unit
) {
    Column {
        ListItem(
            headlineContent = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            supportingContent = {
                Column {
                    Text("by ${item.author}")
                    Text("⬇ ${item.downloads}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
            },
            trailingContent = {
                IconButton(onClick = onExpand) {
                    Icon(
                        if (item.isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null
                    )
                }
            }
        )

        if (item.isExpanded) {
            if (item.isLoadingFiles) {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                }
            } else {
                item.ggufFiles.forEach { sibling ->
                    val progress = downloadProgress[item.repoId]
                    GgufFileRow(
                        sibling = sibling,
                        onDownload = { onDownload(sibling) }
                    )
                }
                if (item.ggufFiles.isEmpty()) {
                    Text(
                        "GGUF файлы не найдены",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.outline,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun GgufFileRow(
    sibling: HFFileSibling,
    onDownload: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(sibling.filename, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val size = sibling.lfs?.size ?: sibling.size
            if (size != null) {
                Text(formatSize(size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        }
        OutlinedButton(onClick = onDownload, modifier = Modifier.padding(start = 8.dp)) {
            Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("Скачать", style = MaterialTheme.typography.labelMedium)
        }
    }
}

private fun onChangeAndSearch(s: String, fn: (String) -> Unit) = fn(s)

private fun formatSize(bytes: Long): String {
    return when {
        bytes >= 1_073_741_824L -> "%.1f GB".format(bytes / 1_073_741_824.0)
        bytes >= 1_048_576L -> "%.1f MB".format(bytes / 1_048_576.0)
        bytes >= 1024L -> "%.1f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}
