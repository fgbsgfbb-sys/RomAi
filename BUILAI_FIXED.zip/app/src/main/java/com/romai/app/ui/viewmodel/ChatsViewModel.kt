package com.romai.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romai.app.data.ChatRepository
import com.romai.app.data.ModelRepository
import com.romai.app.data.SettingsRepository
import com.romai.app.data.model.ChatEntity
import com.romai.app.data.model.ModelEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatsUiState(
    val chats: List<ChatEntity> = emptyList(),
    val localModels: List<ModelEntity> = emptyList(),
    val selectedChatIds: Set<String> = emptySet(),
    val isSelectionMode: Boolean = false,
    val activeModelId: String = "",
    val showNewChatDialog: Boolean = false,
    val newChatTitle: String = "",
    val newChatSystemPrompt: String = ""
)

@HiltViewModel
class ChatsViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val modelRepository: ModelRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatsUiState())
    val uiState: StateFlow<ChatsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            chatRepository.allChats.collect { chats ->
                _uiState.update { it.copy(chats = chats) }
            }
        }
        viewModelScope.launch {
            modelRepository.localModels.collect { models ->
                _uiState.update { it.copy(localModels = models) }
            }
        }
        viewModelScope.launch {
            settingsRepository.settings.collect { s ->
                _uiState.update { it.copy(activeModelId = s.activeModelId) }
            }
        }
    }

    fun createChat(title: String, modelId: String, systemPrompt: String = "") {
        viewModelScope.launch {
            chatRepository.createChat(modelId, title.ifBlank { "Новый чат" }, systemPrompt)
            _uiState.update { it.copy(showNewChatDialog = false, newChatTitle = "", newChatSystemPrompt = "") }
        }
    }

    fun deleteChat(chat: ChatEntity) {
        viewModelScope.launch { chatRepository.deleteChat(chat) }
    }

    fun deleteSelectedChats() {
        viewModelScope.launch {
            chatRepository.deleteChats(_uiState.value.selectedChatIds.toList())
            _uiState.update { it.copy(selectedChatIds = emptySet(), isSelectionMode = false) }
        }
    }

    fun deleteAllChats() {
        viewModelScope.launch {
            chatRepository.deleteAllChats()
            _uiState.update { it.copy(selectedChatIds = emptySet(), isSelectionMode = false) }
        }
    }

    fun toggleSelection(chatId: String) {
        _uiState.update { state ->
            val newSet = state.selectedChatIds.toMutableSet()
            if (newSet.contains(chatId)) newSet.remove(chatId) else newSet.add(chatId)
            state.copy(selectedChatIds = newSet, isSelectionMode = newSet.isNotEmpty())
        }
    }

    fun selectAll() {
        _uiState.update { state ->
            state.copy(selectedChatIds = state.chats.map { it.id }.toSet(), isSelectionMode = true)
        }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedChatIds = emptySet(), isSelectionMode = false) }
    }

    fun showNewChatDialog() = _uiState.update { it.copy(showNewChatDialog = true) }
    fun dismissNewChatDialog() = _uiState.update { it.copy(showNewChatDialog = false) }
    fun onNewChatTitleChange(v: String) = _uiState.update { it.copy(newChatTitle = v) }
    fun onNewChatSystemPromptChange(v: String) = _uiState.update { it.copy(newChatSystemPrompt = v) }
}
